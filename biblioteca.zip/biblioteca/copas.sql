CREATE TABLE copa (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ano INT,
    sede VARCHAR(100),
    campeao VARCHAR(100),
    continente VARCHAR(50),
    representacao VARCHAR(100),
    modelo VARCHAR(100)
);