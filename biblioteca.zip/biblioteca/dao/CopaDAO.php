<?php

require_once("util/conexao.php");
Class CopaDAO{

     private $conn;

    public function __construct() {
        $this->conn = Conexao::conectar();
    }
}

//Listagem dos livros
$sql = "SELECT * FROM livros";
$stm = $conexao->prepare($sql);
$stm->execute();
$livros = $stm->fetchAll();

//echo "<pre>" . print_r($livros, true) . "</pre>";

function procurarLivro($titulo, $conexao){
    $sql = "SELECT titulo FROM livros WHERE titulo = ?";
    $stm = $conexao->prepare($sql);
    $stm->execute([$titulo]);
    return count($stm->fetchAll())>0;
}